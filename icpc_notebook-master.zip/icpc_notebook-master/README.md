# icpc_notebook
Team notebook of Trie_NP_Hard

It contains most of the baisc/intermediate standard algorithms. Exact details can be found on the index page(2nd page).

Most of the code has been taken from geeksforgeeks.org

Times new roman, size 12 has been used as standard font to respect the rules at kolkata/ amritapuri.

The page ordering is as follows:

1. left half 1 to 23
2. right half 1 to 23

If you feel that I have missed something, please let me know.

Use PDF file for printing to avoid printing suprises.

Use DOC file to make any modification.

All the best for ICPC :)
